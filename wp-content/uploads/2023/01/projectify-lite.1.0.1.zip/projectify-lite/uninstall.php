<?php
if (!defined('WP_UNINSTALL_PLUGIN')) {
    wp_die();
}
